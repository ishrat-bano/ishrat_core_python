"""
Building a small labeled set of restaurant-style reviews to train a
sentiment classifier on. I put this together from templates + a bit of
random mixing rather than scraping real reviews, just needed something with
enough variety and clear positive/negative signal to train on.
"""

import random
import pandas as pd

random.seed(11)

positive_templates = [
    "The food here was absolutely {adj}, we will definitely come back.",
    "{adj} service and the {dish} was cooked perfectly.",
    "Loved this place, the {dish} was {adj} and the staff were friendly.",
    "Best {dish} I've had in years, truly {adj}.",
    "Great atmosphere, {adj} food, reasonable prices.",
    "The {dish} exceeded my expectations, {adj} experience overall.",
    "Staff were attentive and the {dish} was {adj}, highly recommend.",
    "Such a {adj} evening, the {dish} alone was worth the visit.",
]

negative_templates = [
    "The {dish} was {adj}, honestly disappointed with the whole meal.",
    "Service was slow and the {dish} arrived cold and {adj}.",
    "Would not recommend, the {dish} tasted {adj}.",
    "{adj} experience, waited over an hour and the food wasn't even good.",
    "The {dish} was overpriced and {adj}, won't be returning.",
    "Rude staff and a {adj} {dish}, not worth the money.",
    "Terrible visit, {adj} food and a dirty table.",
    "Bland and {adj}, the {dish} needed way more seasoning.",
]

pos_adj = ["amazing", "fantastic", "wonderful", "excellent", "delicious", "outstanding", "lovely", "great"]
neg_adj = ["awful", "bland", "disappointing", "terrible", "cold", "stale", "overcooked", "flavorless"]
dishes = ["pasta", "burger", "steak", "curry", "pizza", "salad", "soup", "sushi", "sandwich", "ramen"]

rows = []
for _ in range(250):
    t = random.choice(positive_templates)
    rows.append({
        "review": t.format(adj=random.choice(pos_adj), dish=random.choice(dishes)),
        "sentiment": "positive",
    })
for _ in range(250):
    t = random.choice(negative_templates)
    rows.append({
        "review": t.format(adj=random.choice(neg_adj), dish=random.choice(dishes)),
        "sentiment": "negative",
    })

df = pd.DataFrame(rows).sample(frac=1, random_state=1).reset_index(drop=True)
df.to_csv("data/reviews.csv", index=False)
print(df.shape)
print(df["sentiment"].value_counts())
