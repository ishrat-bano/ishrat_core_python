# Restaurant Review Sentiment Analysis

Text classification project - reading a restaurant review and deciding if
it's positive or negative. Classic NLP starter project, using TF-IDF to
turn text into numbers and then a couple of standard classifiers on top.

## Dataset

`data/reviews.csv` - 500 reviews, roughly half positive/half negative. I
generated these from a set of sentence templates (`generate_data.py`)
mixing different dishes and adjectives, rather than scraping real reviews.
Worth being upfront about: because it's template-based, the model hits
100% accuracy on the test set, which is a sign the data is easier than real
reviews would be, not that the model is magic. Real-world review text is
messier - sarcasm, mixed sentiment in one review, typos, etc.

## What I did

1. Split into train/test (75/25, stratified so both sets have equal pos/neg).
2. Vectorized text with TF-IDF, using both single words and bigrams
   (`ngram_range=(1,2)`) so it can pick up on phrases like "not worth" too,
   not just individual words.
3. Trained a Multinomial Naive Bayes and a Logistic Regression, compared
   accuracy.
4. Pulled out the words/phrases with the strongest positive and negative
   coefficients from the logistic regression - kind of fun to see what the
   model actually latched onto ("cold", "bland", "rude" on the negative
   side, "delicious", "fantastic" on the positive side).
5. Ran a couple of hand-written test sentences through the trained model
   as a sanity check.

## Results

Both models hit 100% on this dataset (again, expected given how it was
generated). Logistic regression correctly classified all 3 unseen test
sentences I wrote by hand, including a slightly ambiguous one ("it was
fine, nothing special but not bad either" got classified as positive,
which is debatable - shows the limits of a small template-trained model).

## Files

- `generate_data.py` - builds the review dataset
- `sentiment.py` - vectorizing, training, evaluation, and the word
  importance breakdown
- `images/confusion_matrix.png`

## Running it

```
pip install pandas scikit-learn matplotlib seaborn
python generate_data.py
python sentiment.py
```

## Where this breaks down / next steps

- Swap in a real dataset (Yelp reviews, IMDB, Amazon reviews) to get a much
  more honest sense of accuracy
- Try adding neutral/mixed as a third class instead of forcing everything
  into positive or negative
- A pretrained transformer (like DistilBERT) would handle sarcasm and
  nuance way better than TF-IDF + linear models
