"""
Restaurant Review Sentiment Analysis

Simple text classification - is a review positive or negative? Using
TF-IDF for features and comparing Naive Bayes vs Logistic Regression.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

df = pd.read_csv("data/reviews.csv")
print(df.shape)
print(df.sample(5))

X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["sentiment"], test_size=0.25, random_state=42, stratify=df["sentiment"]
)

vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=1500)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

nb = MultinomialNB()
nb.fit(X_train_vec, y_train)
nb_preds = nb.predict(X_test_vec)

log_reg = LogisticRegression(max_iter=500)
log_reg.fit(X_train_vec, y_train)
lr_preds = log_reg.predict(X_test_vec)

print("\nNaive Bayes accuracy:", accuracy_score(y_test, nb_preds))
print("Logistic Regression accuracy:", accuracy_score(y_test, lr_preds))
print("\nLogistic Regression report:\n", classification_report(y_test, lr_preds))

cm = confusion_matrix(y_test, lr_preds, labels=["positive", "negative"])
plt.figure(figsize=(4.5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Purples",
            xticklabels=["positive", "negative"], yticklabels=["positive", "negative"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Logistic Regression - confusion matrix")
plt.tight_layout()
plt.savefig("images/confusion_matrix.png", dpi=120)
plt.close()

# words that push the model most towards each class
feature_names = vectorizer.get_feature_names_out()
coefs = log_reg.coef_[0]
top_pos = pd.Series(coefs, index=feature_names).sort_values(ascending=False).head(10)
top_neg = pd.Series(coefs, index=feature_names).sort_values().head(10)

print("\nWords most associated with positive reviews:")
print(top_pos)
print("\nWords most associated with negative reviews:")
print(top_neg)


def predict_review(text):
    vec = vectorizer.transform([text])
    return log_reg.predict(vec)[0]


# quick sanity checks on sentences the model has never seen
tests = [
    "The staff were incredibly rude and the pasta was cold",
    "Best meal I've had all year, absolutely fantastic",
    "It was fine, nothing special but not bad either",
]
print("\nSanity check on new sentences:")
for t in tests:
    print(f"  '{t}' -> {predict_review(t)}")

print("\ndone")
