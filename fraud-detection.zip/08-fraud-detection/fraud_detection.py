"""
Credit Card Fraud Detection

Classic imbalanced classification problem - only ~1.5% of transactions are
fraud, so plain accuracy is a useless metric here (a model that never
predicts fraud would still be ~98% "accurate"). Focusing on precision,
recall, and PR-AUC instead, and comparing a baseline model against one
trained with class weighting.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    precision_recall_curve, average_precision_score
)

df = pd.read_csv("data/transactions.csv")
print(df.shape)
print(df["is_fraud"].value_counts(normalize=True))

plt.figure(figsize=(4, 4))
df["is_fraud"].value_counts().plot(kind="bar", color=["steelblue", "crimson"])
plt.xticks([0, 1], ["Legit", "Fraud"], rotation=0)
plt.title("Class imbalance")
plt.tight_layout()
plt.savefig("images/class_balance.png", dpi=120)
plt.close()

X = df.drop(columns="is_fraud")
y = df["is_fraud"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=1, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# baseline: logistic regression with no adjustment for imbalance
baseline = LogisticRegression(max_iter=1000)
baseline.fit(X_train_s, y_train)
baseline_preds = baseline.predict(X_test_s)

print("\n--- Baseline Logistic Regression ---")
print(classification_report(y_test, baseline_preds, digits=3))

# now with class_weight='balanced' so the model actually pays attention
# to the minority class instead of just predicting "legit" every time
weighted = LogisticRegression(max_iter=1000, class_weight="balanced")
weighted.fit(X_train_s, y_train)
weighted_preds = weighted.predict(X_test_s)

print("--- Class-weighted Logistic Regression ---")
print(classification_report(y_test, weighted_preds, digits=3))

rf = RandomForestClassifier(n_estimators=200, class_weight="balanced", random_state=1)
rf.fit(X_train, y_train)  # trees don't need scaled features
rf_preds = rf.predict(X_test)
rf_proba = rf.predict_proba(X_test)[:, 1]

print("--- Random Forest (class-weighted) ---")
print(classification_report(y_test, rf_preds, digits=3))
print("ROC-AUC:", roc_auc_score(y_test, rf_proba))
print("Average precision (PR-AUC):", average_precision_score(y_test, rf_proba))

cm = confusion_matrix(y_test, rf_preds)
plt.figure(figsize=(4, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Reds", xticklabels=["Legit", "Fraud"], yticklabels=["Legit", "Fraud"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Random Forest confusion matrix")
plt.tight_layout()
plt.savefig("images/confusion_matrix.png", dpi=120)
plt.close()

precision, recall, thresholds = precision_recall_curve(y_test, rf_proba)
plt.figure(figsize=(6, 5))
plt.plot(recall, precision)
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision-Recall curve (Random Forest)")
plt.tight_layout()
plt.savefig("images/precision_recall_curve.png", dpi=120)
plt.close()

print("\ndone")
