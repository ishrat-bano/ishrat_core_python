# Credit Card Fraud Detection

Detecting fraudulent transactions in a highly imbalanced dataset (~2% fraud).
The real point of this project is less about the model and more about
handling class imbalance correctly - accuracy is basically a useless metric
here since a model that just predicts "not fraud" every single time would
still score ~98%.

## Dataset

`data/transactions.csv` - 20,000 simulated transactions, ~2% fraud. I used
`sklearn.datasets.make_classification` to generate this
(`generate_data.py`) rather than using the real Kaggle credit card fraud
dataset, mainly because that dataset's features are already anonymized PCA
components anyway (V1-V28), so simulating something with the same shape and
imbalance gets you basically the same learning experience. Added an
`amount` and `hour` column on top to make it feel more like real
transaction data.

## What I did

1. Checked the class balance first - 1.98% fraud, confirms this needs
   special handling, not just `model.fit()` and done.
2. Trained a baseline Logistic Regression (no imbalance handling) - it
   gets 100% precision but only 20% recall on fraud. Looks "accurate" on
   paper but is actually missing 80% of fraud cases, which is the whole
   thing you're trying to catch.
3. Retrained with `class_weight='balanced'` - recall jumps way up (74%) but
   precision drops (a lot more false alarms). Classic precision/recall
   tradeoff.
4. Tried a Random Forest as well, also class-weighted, and looked at
   ROC-AUC and PR-AUC instead of just accuracy since those actually mean
   something on imbalanced data.
5. Plotted the precision-recall curve so you can see the tradeoff across
   different thresholds rather than just one cutoff point.

## Results

| Model | Precision (fraud) | Recall (fraud) |
|---|---|---|
| Logistic Regression (baseline) | 1.00 | 0.20 |
| Logistic Regression (weighted) | 0.06 | 0.74 |
| Random Forest (weighted) | 1.00 | 0.16 |

ROC-AUC: 0.87, PR-AUC: 0.62 for the Random Forest.

None of these are "the right answer" by themselves - which one you'd
actually deploy depends on the cost of missing fraud vs the cost of
annoying legitimate customers with false flags. That's really the
takeaway of this project.

## Files

- `generate_data.py` - builds the simulated transaction data
- `fraud_detection.py` - baseline vs weighted models, precision-recall curve
- `images/class_balance.png`, `images/confusion_matrix.png`,
  `images/precision_recall_curve.png`

## Running it

```
pip install pandas numpy scikit-learn matplotlib seaborn
python generate_data.py
python fraud_detection.py
```

## Next steps

- Try SMOTE (oversampling the minority class) instead of just class
  weighting
- Pick a probability threshold based on the precision-recall curve rather
  than the default 0.5
- If using the real Kaggle dataset, add time-based features - fraud often
  clusters in bursts
