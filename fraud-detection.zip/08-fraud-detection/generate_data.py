"""
Simulating a credit card transactions dataset with a small % of fraud,
similar in spirit to the well-known Kaggle credit card fraud dataset (which
is anonymized PCA components anyway, so there's not much lost by
simulating something similar). Using sklearn's make_classification to get
a realistic class imbalance and some feature overlap between classes.
"""

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification

X, y = make_classification(
    n_samples=20000,
    n_features=10,
    n_informative=6,
    n_redundant=2,
    weights=[0.985, 0.015],  # ~1.5% fraud, similar order of magnitude to the real dataset
    class_sep=0.9,
    flip_y=0.01,
    random_state=17,
)

cols = [f"V{i+1}" for i in range(X.shape[1])]
df = pd.DataFrame(X, columns=cols)

# add a couple of features that actually look like transaction data
rng = np.random.default_rng(17)
df["amount"] = np.round(np.abs(rng.normal(60, 90, len(df))) + df["V1"].abs() * 20, 2)
df["hour"] = rng.integers(0, 24, len(df))
df["is_fraud"] = y

df.to_csv("data/transactions.csv", index=False)
print(df.shape)
print(df["is_fraud"].value_counts())
print("fraud rate: {:.2f}%".format(df["is_fraud"].mean() * 100))
