# Simple Movie Recommender

Basic item-based collaborative filtering system - "people who liked this
movie also liked these". No deep learning, no fancy matrix factorization,
just cosine similarity on user ratings. This is meant to show the core idea
behind recommendation systems before jumping into more complex approaches.

## Dataset

`data/movies.csv` and `data/ratings.csv` - I made these up
(`generate_data.py`) since I didn't want to deal with downloading and
licensing the full MovieLens dataset for a small demo. 20 movies across 4
genres, 120 fake users, ~1300 ratings total. Users have a couple of genres
they tend to prefer, which is what gives the recommender something real to
pick up on.

## How it works

1. Build a user x movie matrix from the ratings (rows = users, columns =
   movies, values = rating, 0 where they haven't rated it).
2. Compute cosine similarity between every pair of movies based on that
   matrix - movies that get rated similarly by the same users end up
   "close" to each other.
3. `recommend(movie_id)` - given a movie, returns the most similar ones.
4. `recommend_for_user(user_id)` - looks at everything a user has rated,
   weights similar movies by how much they liked what they've already seen,
   and returns the top scoring unseen movies.

## Example output

Recommending based on "The Last Horizon" (a Sci-Fi movie) correctly surfaces
other Sci-Fi titles near the top ("Mars Protocol", "Nebula Drift").

## Files

- `generate_data.py` - builds the fake movies/ratings data
- `recommender.py` - similarity calculation + the two recommend functions
- `data/movies.csv`, `data/ratings.csv`

## Running it

```
pip install pandas numpy scikit-learn
python generate_data.py
python recommender.py
```

## Limitations / next steps

- This is a toy dataset, so don't read too much into the exact numbers -
  the point is showing the mechanism
- Cold start problem: doesn't work for a movie/user with no ratings yet
- Worth trying matrix factorization (SVD) next, it usually handles sparse
  data better than plain cosine similarity
- Could swap in the real MovieLens 100k dataset if you want to test against
  actual human ratings
