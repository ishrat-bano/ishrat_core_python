"""
Making a small fake ratings dataset, movielens-style (userId, movieId,
rating). Built it so movies naturally cluster into a few "genres" that
users tend to like consistently, otherwise the recommendations end up
looking like random noise and there's nothing interesting to show.
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(3)

movies = [
    (1, "The Last Horizon", "Sci-Fi"),
    (2, "Silent Orbit", "Sci-Fi"),
    (3, "Mars Protocol", "Sci-Fi"),
    (4, "Nebula Drift", "Sci-Fi"),
    (5, "Comedy Night Live", "Comedy"),
    (6, "Office Chaos", "Comedy"),
    (7, "The Wedding Disaster", "Comedy"),
    (8, "Laugh Track", "Comedy"),
    (9, "Midnight Killer", "Thriller"),
    (10, "The Watcher", "Thriller"),
    (11, "Dead End Street", "Thriller"),
    (12, "Vanishing Point", "Thriller"),
    (13, "Love in Paris", "Romance"),
    (14, "Second Chances", "Romance"),
    (15, "Autumn Letters", "Romance"),
    (16, "Forever Yours", "Romance"),
    (17, "Galaxy Wars", "Sci-Fi"),
    (18, "The Funny Guy", "Comedy"),
    (19, "Shadow Hunter", "Thriller"),
    (20, "One More Summer", "Romance"),
]
movies_df = pd.DataFrame(movies, columns=["movieId", "title", "genre"])

n_users = 120
genre_prefs = ["Sci-Fi", "Comedy", "Thriller", "Romance"]

rows = []
for user_id in range(1, n_users + 1):
    # each user likes 1-2 genres more than others
    liked = rng.choice(genre_prefs, size=rng.integers(1, 3), replace=False)
    for _, m in movies_df.iterrows():
        # not every user rates every movie
        if rng.random() > 0.55:
            continue
        base = 4.2 if m["genre"] in liked else 2.6
        rating = np.clip(rng.normal(base, 0.9), 1, 5)
        rows.append({"userId": user_id, "movieId": m["movieId"], "rating": round(rating * 2) / 2})

ratings_df = pd.DataFrame(rows)
movies_df.to_csv("data/movies.csv", index=False)
ratings_df.to_csv("data/ratings.csv", index=False)
print("movies:", movies_df.shape, "ratings:", ratings_df.shape)
