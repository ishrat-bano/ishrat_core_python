"""
Simple Movie Recommender

Item-based collaborative filtering - "people who liked this movie also
liked...". Nothing fancy, just cosine similarity between movies based on
how users rated them.
"""

import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

movies = pd.read_csv("data/movies.csv")
ratings = pd.read_csv("data/ratings.csv")

print("movies:", movies.shape, "ratings:", ratings.shape)
print(ratings.head())

# build a user x movie ratings matrix, missing = 0 for the similarity calc
pivot = ratings.pivot_table(index="userId", columns="movieId", values="rating").fillna(0)

# cosine similarity between movies based on rating patterns
sim_matrix = cosine_similarity(pivot.T)
sim_df = pd.DataFrame(sim_matrix, index=pivot.columns, columns=pivot.columns)


def recommend(movie_id, n=5):
    """Return the top n movies most similar to movie_id."""
    if movie_id not in sim_df.columns:
        return pd.DataFrame()
    scores = sim_df[movie_id].drop(movie_id).sort_values(ascending=False).head(n)
    result = movies.set_index("movieId").loc[scores.index].copy()
    result["similarity"] = scores.values.round(3)
    return result.reset_index()


def recommend_for_user(user_id, n=5):
    """Recommend movies a user hasn't seen, weighted by how they rated similar movies."""
    user_ratings = pivot.loc[user_id]
    seen = user_ratings[user_ratings > 0].index

    scores = pd.Series(0.0, index=pivot.columns)
    for m in seen:
        scores += sim_df[m] * user_ratings[m]
    scores = scores.drop(seen)  # don't recommend what they already rated

    top = scores.sort_values(ascending=False).head(n)
    result = movies.set_index("movieId").loc[top.index].copy()
    result["score"] = top.values.round(2)
    return result.reset_index()


# demo: pick a sci-fi movie, see what it recommends
print("\nBecause you liked 'The Last Horizon' (Sci-Fi):")
print(recommend(1, n=5)[["title", "genre", "similarity"]])

print("\nRecommendations for user 1:")
print(recommend_for_user(1, n=5)[["title", "genre", "score"]])

print("\nRecommendations for user 2:")
print(recommend_for_user(2, n=5)[["title", "genre", "score"]])
