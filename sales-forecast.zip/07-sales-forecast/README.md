# Sales Forecasting (Time Series)

Forecasting next year's monthly sales for a retail store using 5 years of
history. Using Holt-Winters exponential smoothing, which handles trend and
seasonality (holiday bumps, slow Jan/Feb) without needing to manually
engineer features like you would for a plain regression approach.

## Dataset

`data/monthly_sales.csv` - 60 months of sales (Jan 2019 - Dec 2023). I
generated this (`generate_data.py`) with an upward trend plus seasonal
multipliers (higher in Nov/Dec for holiday shopping, lower in Jan/Feb) and
some random noise on top, so it behaves like real retail sales data would.

## Approach

1. Plotted the full series first - trend and seasonality are both pretty
   visible just by eye.
2. Held out the last 12 months as a test set, trained Holt-Winters on
   everything before that.
3. Compared against a naive baseline (just predict "same value as this
   month last year") - always worth checking a fancy model actually beats
   the dumb approach.
4. Once I confirmed Holt-Winters was doing better, refit it on the full
   dataset and forecast the next 12 months (2024).

## Results

- Holt-Winters: MAE ~$1,540, MAPE ~3.7%
- Naive baseline: MAE ~$4,520

So the model is doing meaningfully better than just copying last year's
numbers - it's picking up on the underlying trend, not just the seasonal
pattern. 2024 forecast shows the usual holiday spike carrying into
December.

## Files

- `generate_data.py` - builds the sales data
- `forecast.py` - EDA plot, train/test evaluation, and the final forecast
- `images/full_series.png`, `images/forecast_vs_actual.png`,
  `images/future_forecast.png`

## Running it

```
pip install pandas numpy matplotlib scikit-learn statsmodels
python generate_data.py
python forecast.py
```

## Next steps

- Try SARIMA and compare against Holt-Winters
- Add external regressors if you have them (e.g. marketing spend,
  promotions calendar) - Holt-Winters can't use those but SARIMAX can
- Get prediction intervals, not just point forecasts, so you know how much
  to trust the numbers further out
