"""
Generating monthly sales data for a made-up retail store, 2019-2023.
Built in a general upward trend + yearly seasonality (holiday bump in
Nov/Dec, slow period in Jan/Feb) + some random noise, similar to what
real retail sales data usually looks like.
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

dates = pd.date_range("2019-01-01", "2023-12-01", freq="MS")
n = len(dates)

trend = np.linspace(20000, 42000, n)
month_index = dates.month
seasonal_factor = {
    1: 0.85, 2: 0.82, 3: 0.95, 4: 1.0, 5: 1.02, 6: 1.05,
    7: 1.0, 8: 0.98, 9: 1.0, 10: 1.08, 11: 1.25, 12: 1.4,
}
seasonality = np.array([seasonal_factor[m] for m in month_index])
noise = rng.normal(0, 1200, n)

sales = trend * seasonality + noise
sales = np.round(sales, -1).clip(min=0)

df = pd.DataFrame({"date": dates, "sales": sales})
df.to_csv("data/monthly_sales.csv", index=False)
print(df.shape)
print(df.head())
print(df.tail())
