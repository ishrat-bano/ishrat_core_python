"""
Sales Forecasting

Simple time series project - look at 5 years of monthly sales for a retail
store and forecast the next 12 months. Using Holt-Winters exponential
smoothing since it handles trend + seasonality without much fuss, and
comparing it against a naive baseline.
"""

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error

df = pd.read_csv("data/monthly_sales.csv", parse_dates=["date"])
df = df.set_index("date")
print(df.shape)
print(df.head())

plt.figure(figsize=(11, 4))
plt.plot(df.index, df["sales"])
plt.title("Monthly sales, 2019-2023")
plt.ylabel("Sales ($)")
plt.tight_layout()
plt.savefig("images/full_series.png", dpi=120)
plt.close()

# hold out the last 12 months to test the forecast against
train = df.iloc[:-12]
test = df.iloc[-12:]

model = ExponentialSmoothing(
    train["sales"], trend="add", seasonal="add", seasonal_periods=12
).fit()

forecast = model.forecast(12)

# naive baseline: just repeat the same month from last year
naive_forecast = train["sales"].iloc[-12:].values

mae_hw = mean_absolute_error(test["sales"], forecast)
mae_naive = mean_absolute_error(test["sales"], naive_forecast)
mape_hw = mean_absolute_percentage_error(test["sales"], forecast) * 100

print(f"\nHolt-Winters MAE: {mae_hw:,.0f}  (MAPE: {mape_hw:.1f}%)")
print(f"Naive (same month last year) MAE: {mae_naive:,.0f}")

plt.figure(figsize=(11, 5))
plt.plot(train.index, train["sales"], label="train")
plt.plot(test.index, test["sales"], label="actual", color="black")
plt.plot(test.index, forecast, label="Holt-Winters forecast", linestyle="--")
plt.plot(test.index, naive_forecast, label="naive forecast", linestyle=":")
plt.legend()
plt.title("Forecast vs actual (last 12 months held out)")
plt.tight_layout()
plt.savefig("images/forecast_vs_actual.png", dpi=120)
plt.close()

# now refit on the full dataset and forecast the actual next 12 months
full_model = ExponentialSmoothing(
    df["sales"], trend="add", seasonal="add", seasonal_periods=12
).fit()
future = full_model.forecast(12)
print("\nForecast for the next 12 months:")
print(future.round(0))

plt.figure(figsize=(11, 5))
plt.plot(df.index, df["sales"], label="history")
plt.plot(future.index, future, label="forecast", linestyle="--", color="red")
plt.legend()
plt.title("Next 12 months forecast")
plt.tight_layout()
plt.savefig("images/future_forecast.png", dpi=120)
plt.close()

print("\ndone")
